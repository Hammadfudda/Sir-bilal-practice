// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-analytics.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import {
  getFirestore,
  doc,
  setDoc,
} from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyBfCKN2TvCo70fOndagpep9hBgB91ccBQw",
//   authDomain: "loginpage90-c705c.firebaseapp.com",
//   databaseURL: "https://loginpage90-c705c-default-rtdb.firebaseio.com",
//   projectId: "loginpage90-c705c",
//   storageBucket: "loginpage90-c705c.appspot.com",
//   messagingSenderId: "442679274933",
//   appId: "1:442679274933:web:fbf7a1f9562a326881bdfc"
// };

// const firebaseConfig = {
//   apiKey: "AIzaSyBfCKN2TvCo70fOndagpep9hBgB91ccBQw",
//   authDomain: "loginpage90-c705c.firebaseapp.com",
//   databaseURL: "https://loginpage90-c705c-default-rtdb.firebaseio.com",
//   projectId: "loginpage90-c705c",
//   storageBucket: "loginpage90-c705c.appspot.com",
//   messagingSenderId: "442679274933",
//   appId: "1:442679274933:web:fbf7a1f9562a326881bdfc"
// };
const firebaseConfig = {
  apiKey: "AIzaSyCqQI2C6eqbQW2s3AYuFG7mmNq-MRAlGUY",
  authDomain: "myproject-51fd7.firebaseapp.com",
  databaseURL: "https://myproject-51fd7-default-rtdb.firebaseio.com",
  projectId: "myproject-51fd7",
  storageBucket: "myproject-51fd7.appspot.com",
  messagingSenderId: "797837942304",
  appId: "1:797837942304:web:97950a056bff9b3569a645"
};
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth();
const db = getFirestore();

let username = document.getElementById("username");
let email = document.getElementById("email");
let password = document.getElementById("password");

window.signupUser = () => {
  let obj = {
    username: username.value,
    email: email.value,
    password: password.value,
  };
  console.log(obj);

  createUserWithEmailAndPassword(auth, obj.email, obj.password)
    .then((res) => {
      obj.id = res.user.uid;
      obj.userType = "user";
      delete obj.password;

      const refernce = doc(db, "users", obj.id);
      setDoc(refernce, obj)
        .then(() => {
          const userObj = JSON.stringify(obj);
          localStorage.setItem("user", userObj);
          window.location.replace("../../index.html");
        })
        .catch((err) => {
          alert(err.message);
        });
    })
    .catch((err) => {
      alert(err.message);
    });
};
