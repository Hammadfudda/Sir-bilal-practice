// let a = [1, 2, 3];
// let b = {
//   id: 1,
//   name: "ABC",
// };

// a[0] = 5;
// a.1 = 20
// console.log(a);

// b["id"] = 10;
// b.name = "ashd";
// console.log(b);
